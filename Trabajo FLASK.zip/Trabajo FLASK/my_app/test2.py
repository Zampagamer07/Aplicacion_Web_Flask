from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.secret_key = 'mi_clave_secreta'

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_BINDS'] = {'juegos': 'sqlite:///Juegos.db'}
app.config['SQLALCHEMY_BINDS'] = {'juegos': 'sqlite:///Reserva.db'}
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    gmail = db.Column(db.String(150), nullable=False)
    telefono = db.Column(db.String(20), nullable=False)
    fecha_nacimiento = db.Column(db.String(20), nullable=False)
    password_hash = db.Column(db.String(150), nullable=False)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Reserva(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    usuario_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    juego_reservado = db.Column(db.String(100), nullable=False)
    fecha_reserva = db.Column(db.String(50), nullable=False)
    fecha_devolucion = db.Column(db.String(50), nullable=False)

class Juegos(db.Model):
    id_juego = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(150), nullable=False)
    stock = db.Column(db.Integer, nullable=False)


@app.route('/')
def home():
    if "username" in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('index.html')
    username = request.form['username']
    password = request.form['password']

    user = User.query.filter_by(username=username).first()
    if user and user.check_password(password):
        session["username"] = username
        return redirect(url_for('dashboard'))
    else:
        flash('Usuario o contraseña incorrecto.', 'Error')
        return render_template('index.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == "POST":
        username = request.form['username']
        gmail = request.form['gmail']
        telefono = request.form['telefono']
        fecha_nacimiento = request.form['fecha_nacimiento']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user:
            flash('Ya existe un usuario con ese nombre.', 'Error')
            return redirect(url_for('register'))
        else:
            new_user = User(username=username, gmail=gmail, telefono=telefono, fecha_nacimiento=fecha_nacimiento)
            new_user.set_password(password)
            db.session.add(new_user)
            db.session.commit()

            flash('Usuario creado correctamente.', 'Éxito')
            return redirect(url_for('login'))

    return render_template('register.html')


@app.route('/dashboard')
def dashboard():
    if "username" in session:
        usuarios = User.query.all()
        juegos = Juegos.query.all()
        reservas = Reserva.query.all()

        return render_template(
            'dashboard.html',
            username=session['username'],
            usuarios=usuarios,
            juegos=juegos,
            reservas=reservas
        )
    else:
        return redirect(url_for('login'))


@app.route('/logout')
def logout():
    session.pop("username", None)
    return redirect(url_for('login'))


@app.route('/admin_usuarios')
def admin_usuarios():
    if "username" in session:
        usuarios = User.query.all()
        return render_template('admin_usuarios.html', usuarios=usuarios)
    else:
        return redirect(url_for('login'))

@app.route('/crear_usuario', methods=['GET', 'POST'])
def crear_usuario():
    if "username" in session:
        if request.method == 'POST':
            username = request.form['username']
            gmail = request.form['gmail']
            telefono = request.form['telefono']
            fecha_nacimiento = request.form['fecha_nacimiento']
            password = request.form['password']

            user = User.query.filter_by(username=username).first()
            if user:
                flash('Ya existe un usuario con ese nombre.', 'Error')
                return redirect(url_for('crear_usuario'))
            else:
                new_user = User(
                    username=username,
                    gmail=gmail,
                    telefono=telefono,
                    fecha_nacimiento=fecha_nacimiento
                )
                new_user.set_password(password)
                db.session.add(new_user)
                db.session.commit()
                flash('Usuario creado correctamente.', 'Éxito')
                return redirect(url_for('admin_usuarios'))
        return render_template('form_editar_usuario.html')
    else:
        return redirect(url_for('login'))


@app.route('/editar_usuario/<int:id>', methods=['GET', 'POST'])
def editar_usuario(id):
    if "username" in session:
        usuario = User.query.get(id)

        if request.method == 'POST':
            nuevo_username = request.form['username']
            nuevo_gmail = request.form['gmail']
            nuevo_telefono = request.form['telefono']
            nuevo_fecha_nacimiento = request.form['fecha_nacimiento']
            nuevo_password = request.form['password']
            
            if User.query.filter_by(username=nuevo_username).first() and nuevo_username != usuario.username:
                flash('Ya existe un usuario con ese nombre.', 'Error')
                return redirect(url_for('editar_usuario', id=id))
            
            usuario.username = nuevo_username
            usuario.gmail = nuevo_gmail
            usuario.telefono = nuevo_telefono
            usuario.fecha_nacimiento = nuevo_fecha_nacimiento
            usuario.set_password(nuevo_password)
            db.session.commit()
            flash('Usuario actualizado correctamente.', 'Éxito')
            return redirect(url_for('admin_usuarios'))

        return render_template('form_editar_usuario.html', usuario=usuario)
    else:
        return redirect(url_for('login'))


@app.route('/eliminar_usuario/<int:id>', methods=['GET', 'POST'])
def eliminar_usuario(id):
    if "username" in session:
        if id == 1:
            flash('No puedes eliminar al administrador.', 'Error')
            return redirect(url_for('admin_usuarios'))

        usuario = User.query.get(id)
        if usuario:
            db.session.delete(usuario)
            db.session.commit()
            flash('Usuario eliminado correctamente.', 'Éxito')
        else:
            flash('Usuario no encontrado.', 'Error')
        return redirect(url_for('admin_usuarios'))
    else:
        return redirect(url_for('login'))

@app.route('/admin_juegos')
def admin_juegos():
    if "username" in session:
        juegos = Juegos.query.all()
        return render_template('admin_juegos.html', juegos=juegos)
    else:
        return redirect(url_for('login'))

@app.route('/crear_juego', methods=['GET', 'POST'])
def crear_juego():
    if "username" in session:
        if request.method == 'POST':
            nombre = request.form['nombre']
            stock = request.form['stock']
            nuevo_juego = Juegos(nombre=nombre, stock=stock)
            db.session.add(nuevo_juego)
            db.session.commit()
            return redirect(url_for('admin_juegos'))
        return render_template('form_editar_juegos.html')
    else:
        return redirect(url_for('login'))

@app.route('/editar_juego/<int:id>', methods=['GET', 'POST'])
def editar_juego(id):
    if "username" in session:
        juego = Juegos.query.get(id)
        if request.method == 'POST':
            juego.nombre = request.form['nombre']
            juego.stock = request.form['stock']
            db.session.commit()
            flash('Juego actualizado correctamente.', 'Éxito')
            return redirect(url_for('admin_juegos'))
        return render_template('form_editar_juegos.html', juego=juego)
    else:
        return redirect(url_for('login'))

@app.route('/eliminar_juego/<int:id>', methods=['GET', 'POST'])
def eliminar_juego(id):
    if "username" in session:
        juego = Juegos.query.get(id)
        if juego:
            db.session.delete(juego)
            db.session.commit()
            flash('Juego eliminado correctamente.', 'Éxito')
        else:
            flash('Juego no encontrado.', 'Error')
        return redirect(url_for('admin_juegos'))
    else:
        return redirect(url_for('login'))

@app.route('/admin_reservas')
def admin_reservas():
    if "username" in session:
        reservas = Reserva.query.all()
        return render_template('admin_reservas.html', reservas=reservas)
    else:
        return redirect(url_for('login'))

@app.route('/crear_reserva', methods=['GET', 'POST'])
def crear_reserva():
    if "username" in session:
        if request.method == 'POST':
            usuario_id = request.form['usuario_id']
            juego_reservado = request.form['juego_reservado']
            fecha_reserva = request.form['fecha_reserva']
            fecha_devolucion = request.form['fecha_devolucion']
            nueva_reserva = Reserva(
                usuario_id=usuario_id,
                juego_reservado=juego_reservado,
                fecha_reserva=fecha_reserva,
                fecha_devolucion=fecha_devolucion
            )
            db.session.add(nueva_reserva)
            db.session.commit()
            flash('Reserva creada correctamente.', 'Éxito')
            return redirect(url_for('admin_reservas'))
        return render_template('form_editar_reserva.html')
    else:
        return redirect(url_for('login'))

@app.route('/editar_reserva/<int:id>', methods=['GET', 'POST'])
def editar_reserva(id):
    if "username" in session:
        reserva = Reserva.query.get(id)
        if request.method == 'POST':
            reserva.usuario_id = request.form['usuario_id']
            reserva.juego_reservado = request.form['juego_reservado']
            reserva.fecha_reserva = request.form['fecha_reserva']
            reserva.fecha_devolucion = request.form['fecha_devolucion']
            db.session.commit()
            flash('Reserva actualizada correctamente.', 'Éxito')
            return redirect(url_for('admin_reservas'))
        return render_template('form_editar_reserva.html', reserva=reserva)
    else:
        return redirect(url_for('login'))

@app.route('/eliminar_reserva/<int:id>', methods=['GET', 'POST'])
def eliminar_reserva(id):
    if "username" in session:
        reserva = Reserva.query.get(id)
        if reserva:
            db.session.delete(reserva)
            db.session.commit()
            flash('Reserva eliminada correctamente.', 'Éxito')
        else:
            flash('Reserva no encontrada.', 'Error')
        return redirect(url_for('admin_reservas'))
    else:
        return redirect(url_for('login'))

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)

