document.addEventListener('DOMContentLoaded', function() {
    // Selecciona todos los elementos .btn, <button type="submit"> y <input type="submit">
    const buttons = document.querySelectorAll('.btn, button[type="submit"], input[type="submit"]');

    buttons.forEach(btn => {
        btn.addEventListener('mouseover', function ()  {
            btn.style.transform = "scale(1.2)";
            btn.style.transition = "transform 0.3s ease";
            btn.style.backgroundColor = '#0056b3'; 
        });
        btn.addEventListener('mouseout', function () {
            btn.style.transform = "scale(1)";
            btn.style.backgroundColor = "#006eff"; 
        });
    });
});
document.addEventListener('keydown', function(event) {
    if (event.altKey && event.key.toLowerCase() === 'i') {
        window.location.href = '/login'; 
    }
});